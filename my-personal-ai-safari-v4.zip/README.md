# My Personal AI — Safari V4

Versione pensata per Safari e per la pubblicazione online, senza Node.js Lab.

Include login Supabase, chat persistenti, Admin no-code, personalità AI, selezione modello, ricerca web, prompt suggeriti e manifest web app.

## Setup
1. Crea un progetto Supabase.
2. Esegui `supabase/schema.sql` nel SQL Editor.
3. Inserisci in `.env.local`: URL Supabase, Publishable key, Secret key Supabase, OPENAI_API_KEY e ADMIN_EMAILS.
4. `npm install` poi `npm run dev` per testare.
5. Per pubblicare usa un hosting Next.js come Vercel e configura le stesse variabili d'ambiente.

La Secret key Supabase e la OpenAI API key sono server-side: non inserirle nel codice client.

Dopo la pubblicazione, Safari può aggiungere il sito alla schermata Home. In seguito lo stesso progetto può essere impacchettato come app iOS/Android.
